package org.fhmsyhdproject.moviecatalogue.data.source

import androidx.lifecycle.LiveData
import org.fhmsyhdproject.moviecatalogue.data.MovieEntity

interface MovieDataSource {

    fun getAllMovies(): LiveData<List<MovieEntity>>

    fun getAllTvShow(): LiveData<List<MovieEntity>>

    fun getMovieWithModules(movieId: String): LiveData<MovieEntity>
}