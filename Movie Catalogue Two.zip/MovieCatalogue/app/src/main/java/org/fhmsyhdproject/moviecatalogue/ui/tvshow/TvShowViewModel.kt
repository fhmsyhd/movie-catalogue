package org.fhmsyhdproject.moviecatalogue.ui.tvshow

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import org.fhmsyhdproject.moviecatalogue.data.MovieEntity
import org.fhmsyhdproject.moviecatalogue.data.source.MovieRepository
import org.fhmsyhdproject.moviecatalogue.utils.DataDummy

class TvShowViewModel(private val movieRepository: MovieRepository): ViewModel() {

    fun getTvShow(): LiveData<List<MovieEntity>> = movieRepository.getAllTvShow()
}