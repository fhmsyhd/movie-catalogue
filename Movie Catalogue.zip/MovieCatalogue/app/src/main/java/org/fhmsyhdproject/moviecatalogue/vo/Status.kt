package org.fhmsyhdproject.moviecatalogue.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}